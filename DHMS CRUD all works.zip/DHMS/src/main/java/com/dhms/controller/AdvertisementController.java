package com.dhms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.dhms.dao.AdvertisementRepo;
import com.dhms.model.Advertisement;


@RestController
//@RequestMapping(value = "/advertisement")

public class AdvertisementController {

		
		
		@RequestMapping(value = "/", method = RequestMethod.GET)
		public ModelAndView list() {
			
			ModelAndView model = new ModelAndView("advertisement_list");
			List<Advertisement> advertisementList = getAllAdvertisements();
			model.addObject("advertisementList", advertisementList);
			
			return model;
		}
		
		@RequestMapping(value = "/addAdvertisement/", method = RequestMethod.GET)
		public ModelAndView addAdvertisement() {
			
			ModelAndView model = new ModelAndView();
			Advertisement advertisement = new Advertisement();
			
			model.addObject("advertisementForm", advertisement);
			model.setViewName("advertisement_form");
			
			return model;
			
		}
		
		@RequestMapping(value = "/editAdvertisement", method = RequestMethod.GET)
		public ModelAndView editAdvertisement(@RequestParam long id) {
			
			ModelAndView model = new ModelAndView();
			Advertisement advertisement = getAdvertisementById(id);
			
			model.addObject("advertisementForm", advertisement);
			model.setViewName("advertisement_form");
			
			return model;
		}
		
		@RequestMapping(value = "/saveAdvertisement", method = RequestMethod.POST)
		public ModelAndView save(@ModelAttribute("advertisementForm")Advertisement advertisement) {
			saveOrUpdate(advertisement);
			
			return new ModelAndView("redirect:/");
		}
		
		@RequestMapping(value = "/deleteAdvertisement")
		public ModelAndView delete(@RequestParam("id")long id) {
			deleteAdvertisement(id);
			
			return new ModelAndView("redirect:/");
			
		}
		
		
		@Autowired
		AdvertisementRepo advertisementRepo;

		
		public List<Advertisement> getAllAdvertisements() {
			return (List<Advertisement>) advertisementRepo.findAll();
		}

	
		public Advertisement getAdvertisementById(long id) {
			return advertisementRepo.findById(id).get();	
		}

	
		public void saveOrUpdate(Advertisement advertisement) {
			advertisementRepo.save(advertisement);
		}

		
		public void deleteAdvertisement(long id) {
			advertisementRepo.deleteById(id);	
		}
		
		
	
}

package com.dhms.service;

public interface AdvertisementService {

}
